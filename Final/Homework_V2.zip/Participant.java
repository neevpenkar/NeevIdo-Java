public class Participant {
    public Car car;
    public Driver driver;

    public double raceTime;

    public Participant(){raceTime = 0;}
    public Participant(Car c, Driver d) {
        this.car = c;
        this.driver = d;
        this.raceTime = 0;
    }

    public void calcTime(double distance) {
        double a = this.car.A;
        double v = this.car.V;
        double b = this.driver.B;

        // double c = ((v*v) / (2*a)) + ((v*v) / (2*b));
        // if (c > length) {
        //     calcTime2(length);
        //     return;
        // }

        double t0 = v / a;
        double x0 = (v * v) / (2* a);

        double t1 = v / b;
        double x1 = (v * v) / (2* b);

        double x2 = distance - x0 - x1;
        double t2 = x2 / v;

        this.raceTime += t0 + t2 + t1 + this.driver.Delay;
    }
}
