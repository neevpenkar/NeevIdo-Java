public class Car {

    public String Company;
    public double A;
    public double V;

    public Car(String c, double acc, double sp) {
        this.A = acc;
        this.Company = c;
        this.V = sp;
    }

}
