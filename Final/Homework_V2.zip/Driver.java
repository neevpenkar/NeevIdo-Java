public class Driver {
    
    public String Name;
    public double B;
    public double Delay;

    public Driver(String n, double br, double del) {
        this.B = br;
        this.Name = n;
        this.Delay = del;
    }
}
