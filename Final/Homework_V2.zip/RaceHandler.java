

public class RaceHandler {
    public Participant[] Parts;
    public double[] RaceTimes;

    public int length;

    public int Segments;
    public double[] SegLengths;


    public RaceHandler(){length = 0;}

    public void fromArrays(Car[] c, Driver[] d, int len) {
        Parts = new Participant[len];

        for (int i = 0; i < len; i++) {
            Participant t = new Participant(c[i], d[i]);
            Parts[i] = t;
        }
        length = len;
    }
    public void append(Participant p) {
        Participant[] temp = new Participant[length + 1];
        for (int i = 0; i < length; i++) {
            temp[i] = Parts[i];
        }
        temp[length] = p;

        Parts = temp;
        length += 1;
    }
    public void Print() {
        for (int i = 0; i < length; i++) {
           print(Parts[i].driver.Name + ", " + Parts[i].car.Company + " : " + Parts[i].raceTime);
        }
    }

    public void calcTime() {
        for (int j = 0; j < length; j++) {
            for (int i = 0; i < Segments; i++) {
                this.Parts[j].calcTime(this.SegLengths[i]);
            }
        }
    }


    public static void print(String data) {System.out.println(data);}
}
