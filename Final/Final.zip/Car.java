public class Car {
    public String Company;
    public double Accel;
    public double MaxSpeed;

    public Car() {}
    public Car(String c, double a, double ms) {
        this.Company = c;
        this.Accel = a;
        this.MaxSpeed = ms;
    }

}